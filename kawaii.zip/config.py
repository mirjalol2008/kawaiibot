"""

Kawaii Branch Bot 1.0v

©️Kawaii Uz tomonidan yaratildi
-
🔸Botni ishga tushirish uchun quyidagilarni bajaring:
    1. requirements.txt faylini pip orqali o'rnating
    2. config.py faylini sozlang ( trailers_base_chat , series_base_chat , ads_manager_username , bot_admin_id , main_image)
    3. main.py faylini ishga tushiring
"""

#-----------------------------------------------
trailers_base_chat = -0000000000000 #Telegramda yopiq kanal oching. 
#Kanal nomini "Trailers" nomiga o'zgartiring. Botingizni yopiq kanalga admin qiling va 
#o'sha yopiq kanalingiz ID sini shu yerga yozing

#-----------------------------------------------
series_base_chat = -0000000000000 #Telegramda yopiq kanal oching. 
#Kanal nomini "Series" nomiga o'zgartiring. Botingizni yopiq kanalga admin qiling va 
#o'sha yopiq kanalingiz ID sini shu yerga yozing

#----------------------------------------------- 
token = "1234567890:absdefghijklmnopqrstuvxyzogshchng" #@botfather orqali bot yaratib botingizni tokenini shu yerga yozib qo'ying

#-----------------------------------------------
ads_manager_username = "durov" #Foydalanuvchilar reklama yuzasidan 
#bo'g'lana olishlari uchun telegram akkuntingizni usernamesini "@" belgisini qo'ymagan holda shu yerga yozib qo'ying

#-----------------------------------------------
bot_admin_id = 000000000000 #Botda o'zingini to'liq admin qilish uchun o'z telegram akkuntingiz ID sini shu yerga yozing

#-----------------------------------------------
main_image = "https://img4.teletype.in/files/b1/fa/b1fa9624-f182-4da8-b918-0b33322e3df8.jpeg" #Asosiy menyu rasmi uchun link